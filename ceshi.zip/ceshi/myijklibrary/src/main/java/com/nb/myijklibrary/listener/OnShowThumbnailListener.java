package com.nb.myijklibrary.listener;

import android.widget.ImageView;

/**回传封面的view，让用户自主设置*/
public interface OnShowThumbnailListener {
    void onShowThumbnail(ImageView ivThumbnail);
}
