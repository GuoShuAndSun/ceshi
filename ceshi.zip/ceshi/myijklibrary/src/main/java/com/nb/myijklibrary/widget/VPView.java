package com.nb.myijklibrary.widget;

/**
 * 描 述：
 */
public class VPView {
    public VPView onPause() {
        return this;
    }

    public VPView onResume() {
        return this;
    }

    public VPView setPlaySource() {
        return this;
    }

    public VPView seekTo() {
        return this;
    }

    public VPView start() {
        return this;
    }

    public VPView pause() {
        return this;
    }

    public VPView stop() {
        return this;
    }

    public VPView release() {
        return this;
    }
}
