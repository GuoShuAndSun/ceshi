package com.example.ceshi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class welecome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.layout_welecome);

        new Handler().postDelayed(new Runnable(){
            public void run(){
                //execute the task
                 Intent runmainActiviti=new Intent();

                 runmainActiviti.setClass(welecome.this,MainActivity.class);

                 startActivity(runmainActiviti);
            }

        },3500);
    }



}